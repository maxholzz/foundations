# Foundation Semester Software Engineering 

## Table of contents
* [General info](#general-info)
* [Technologies](#technologies)

## General info
This repo contains my first exercises, experiences and projects related to Software Engineering, done and learned in the foundation semester @CODE University Berlin!
In detail it contains a range of little coding excersices, small websites, servers, tryouts, resources(offerd by our Professor) and also my first big SE Project. (yaaaay!)
The folders are sorted by 1,2,3... for a reason. The reason simply is which part/week of the semester we worked on that topic/exercise.

	
## Technologies
Projects/Excercises/Resources... are created with:
* HTML
* CSS
* Python
* Javascript

![Junior Dev. Meme](https://github.com/lucdoe/foundations/blob/master/1_playground(css%2C%20js)/css_hover/juniorDevPic.jpeg)



